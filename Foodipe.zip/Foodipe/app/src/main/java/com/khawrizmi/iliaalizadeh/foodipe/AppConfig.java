package com.khawrizmi.iliaalizadeh.foodipe;

public class AppConfig {
    public static String URL_LOGIN = "http://192.168.1.2/login.php";

    // Server user register url
    public static String URL_REGISTER = "http://192.168.1.2/register.php";
}
